package verifyaddfunctionality;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class PradnyaShinde {

	
		
		    WebDriver driver;

		    @BeforeClass
		    public void setup() {
		       
		        driver = new ChromeDriver();
		        driver.manage().window().maximize();
		    }

		    @Test
		    public void verifyAddFunctionality() {
		        driver.get("http://qa-assesment.eutech.org/tutorials");

		        // Click on Add Tutorial or go directly to add page if exists
		        WebElement addButton = driver.findElement(By.id("add-tutorial")); // Example locator
		        addButton.click();

		        // Fill title and description
		        WebElement titleInput = driver.findElement(By.id("title"));
		        WebElement descInput = driver.findElement(By.id("description"));
		        WebElement submitBtn = driver.findElement(By.id("submit"));

		        titleInput.sendKeys("pradnya");
		        descInput.sendKeys("Test tutorial description.");
		        submitBtn.click();

		        // Wait for success message or confirmation (can use WebDriverWait here for dynamic wait)
		        WebElement successMessage = driver.findElement(By.xpath("//*[contains(text(),'Tutorial was submitted successfully!')]"));

		        Assert.assertTrue(successMessage.isDisplayed(), "Tutorial was not added successfully.");
		    }

		    @AfterClass
		    public void tearDown() {
		        driver.quit();
		    }
		

	}


